
import React from 'react';

export const AsteroidIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 21a9 9 0 100-18 9 9 0 000 18z" transform="rotate(-45 12 12)" />
  </svg>
);

export const EarthquakeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8h16M4 16h16M8 4l4 4 4-4M8 20l4-4 4 4" />
  </svg>
);

export const EarthIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" {...props}>
      <circle cx="50" cy="50" r="48" fill="currentColor" stroke="#3b82f6" strokeWidth="1"/>
      <path d="M 10,40 A 40,40 0 0 1 20,20 L 25,25 L 30,20 L 35,40 L 30,55 L 20,60 Z" fill="#166534" opacity="0.7" />
      <path d="M 45,20 A 30,30 0 0 1 65,15 L 60,30 L 65,55 L 55,50 Z" fill="#166534" opacity="0.7" />
      <path d="M 70,30 A 25,25 0 0 1 85,45 L 80,60 L 70,55 Z" fill="#166534" opacity="0.7" />
      <path d="M 45,60 A 20,20 0 0 1 60,85 L 50,80 L 45,70 Z" fill="#166534" opacity="0.7" />
    </svg>
);
