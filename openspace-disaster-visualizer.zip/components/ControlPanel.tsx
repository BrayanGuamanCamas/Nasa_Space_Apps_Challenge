
import React from 'react';
import type { AsteroidParams, EarthquakeParams, Location, DisasterMode } from '../types';
import { DisasterMode as DisasterModeEnum } from '../types';
import { PRESET_ASTEROIDS, PRESET_FAULT_LINES } from '../constants';
import { AsteroidIcon, EarthquakeIcon } from './icons/DisasterIcons';

interface ControlPanelProps {
  disasterMode: DisasterMode;
  setDisasterMode: (mode: DisasterMode) => void;
  asteroidParams: AsteroidParams;
  setAsteroidParams: (params: AsteroidParams) => void;
  earthquakeParams: EarthquakeParams;
  setEarthquakeParams: (params: EarthquakeParams) => void;
  setLocation: (location: Location) => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  disasterMode,
  setDisasterMode,
  asteroidParams,
  setAsteroidParams,
  earthquakeParams,
  setEarthquakeParams,
  setLocation
}) => {
    
  const handlePresetAsteroid = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selected = PRESET_ASTEROIDS.find(a => a.name === e.target.value);
    if (selected) {
      setAsteroidParams(prev => ({ ...prev, diameter: selected.diameter, velocity: selected.velocity }));
    }
  };

  const handlePresetFaultLine = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selected = PRESET_FAULT_LINES.find(f => f.name === e.target.value);
    if (selected) {
      setLocation(selected.location);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-6">
      <h2 className="text-2xl font-bold text-cyan-300 border-b-2 border-cyan-500/30 pb-2">Simulation Controls</h2>
      
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">Disaster Mode</label>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setDisasterMode(DisasterModeEnum.Asteroid)}
            className={`flex items-center justify-center space-x-2 p-3 rounded-md text-sm font-semibold transition-all duration-200 ${
              disasterMode === DisasterModeEnum.Asteroid ? 'bg-blue-600 text-white shadow-lg' : 'bg-gray-700 hover:bg-gray-600'
            }`}
          >
            <AsteroidIcon className="w-5 h-5" />
            <span>Asteroid Impact</span>
          </button>
          <button
            onClick={() => setDisasterMode(DisasterModeEnum.Earthquake)}
            className={`flex items-center justify-center space-x-2 p-3 rounded-md text-sm font-semibold transition-all duration-200 ${
              disasterMode === DisasterModeEnum.Earthquake ? 'bg-orange-600 text-white shadow-lg' : 'bg-gray-700 hover:bg-gray-600'
            }`}
          >
            <EarthquakeIcon className="w-5 h-5" />
            <span>Earthquake</span>
          </button>
        </div>
      </div>

      {disasterMode === DisasterModeEnum.Asteroid ? (
        <div className="space-y-4 animate-fade-in">
            <h3 className="text-lg font-semibold text-gray-200">Asteroid Parameters</h3>
             <div>
                <label htmlFor="preset-asteroid" className="block text-sm font-medium text-gray-300 mb-2">Load Real-Data Scenario</label>
                <select id="preset-asteroid" onChange={handlePresetAsteroid} className="w-full bg-gray-700 border-gray-600 text-white rounded-md p-2 focus:ring-blue-500 focus:border-blue-500">
                    <option>Select an Asteroid...</option>
                    {PRESET_ASTEROIDS.map(a => <option key={a.name}>{a.name}</option>)}
                </select>
            </div>
          <div>
            <label htmlFor="diameter" className="block text-sm font-medium text-gray-300">Diameter ({asteroidParams.diameter} m)</label>
            <input id="diameter" type="range" min="10" max="1000" value={asteroidParams.diameter} onChange={e => setAsteroidParams({ ...asteroidParams, diameter: +e.target.value })} className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer range-thumb-blue" />
          </div>
          <div>
            <label htmlFor="velocity" className="block text-sm font-medium text-gray-300">Velocity ({asteroidParams.velocity} km/s)</label>
            <input id="velocity" type="range" min="10" max="70" value={asteroidParams.velocity} onChange={e => setAsteroidParams({ ...asteroidParams, velocity: +e.target.value })} className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer range-thumb-blue" />
          </div>
          <div>
            <label htmlFor="angle" className="block text-sm font-medium text-gray-300">Impact Angle ({asteroidParams.angle}°)</label>
            <input id="angle" type="range" min="10" max="90" value={asteroidParams.angle} onChange={e => setAsteroidParams({ ...asteroidParams, angle: +e.target.value })} className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer range-thumb-blue" />
          </div>
        </div>
      ) : (
        <div className="space-y-4 animate-fade-in">
            <h3 className="text-lg font-semibold text-gray-200">Earthquake Parameters</h3>
            <div>
                <label htmlFor="preset-fault" className="block text-sm font-medium text-gray-300 mb-2">Select Fault Zone</label>
                <select id="preset-fault" onChange={handlePresetFaultLine} className="w-full bg-gray-700 border-gray-600 text-white rounded-md p-2 focus:ring-orange-500 focus:border-orange-500">
                    <option>Select a Fault Line...</option>
                    {PRESET_FAULT_LINES.map(f => <option key={f.name}>{f.name}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="magnitude" className="block text-sm font-medium text-gray-300">Magnitude ({earthquakeParams.magnitude.toFixed(1)})</label>
                <input id="magnitude" type="range" min="6.0" max="9.5" step="0.1" value={earthquakeParams.magnitude} onChange={e => setEarthquakeParams({ ...earthquakeParams, magnitude: +e.target.value })} className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer range-thumb-orange" />
            </div>
        </div>
      )}
      <style jsx>{`
        .range-thumb-blue::-webkit-slider-thumb { background: #3b82f6; }
        .range-thumb-blue::-moz-range-thumb { background: #3b82f6; }
        .range-thumb-orange::-webkit-slider-thumb { background: #ea580c; }
        .range-thumb-orange::-moz-range-thumb { background: #ea580c; }
        .animate-fade-in {
            animation: fadeIn 0.5s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default ControlPanel;
