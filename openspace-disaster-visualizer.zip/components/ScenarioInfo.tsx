
import React from 'react';

interface ScenarioInfoProps {
  info: {
    title: string;
    description: string;
    data: Record<string, string | number>;
  };
  isLoading: boolean;
  error: string | null;
}

const LoadingSpinner: React.FC = () => (
    <div className="flex items-center justify-center h-full">
        <div className="w-16 h-16 border-4 border-t-transparent border-cyan-400 rounded-full animate-spin"></div>
    </div>
);

const ScenarioInfo: React.FC<ScenarioInfoProps> = ({ info, isLoading, error }) => {
  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-red-400">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h3 className="text-xl font-semibold">An Error Occurred</h3>
        <p className="mt-2 text-sm">{error}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full space-y-4 animate-fade-in">
        <h2 className="text-2xl font-bold text-cyan-300 border-b-2 border-cyan-500/30 pb-2">{info.title || 'Scenario Analysis'}</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            {Object.entries(info.data).map(([key, value]) => (
                <div key={key} className="bg-gray-700/50 p-3 rounded-lg">
                    <p className="text-sm text-gray-400">{key}</p>
                    <p className="text-lg font-semibold text-white">{value}</p>
                </div>
            ))}
        </div>
        
        <div className="prose prose-invert prose-sm sm:prose-base max-w-none text-gray-300 flex-grow overflow-y-auto pr-2">
            <p>{info.description || 'Generating scenario description...'}</p>
        </div>
      <style jsx>{`
        .animate-fade-in {
            animation: fadeIn 0.5s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default ScenarioInfo;
