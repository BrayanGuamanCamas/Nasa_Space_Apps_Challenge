
import React, { useRef } from 'react';
import type { Location, DisasterMode } from '../types';
import { DisasterMode as DisasterModeEnum } from '../types';
import { EarthIcon } from './icons/DisasterIcons';

interface VisualizationProps {
  disasterMode: DisasterMode;
  location: Location;
  setLocation: (location: Location) => void;
  blastRadius: number;
  craterSize: number;
  tsunamiRisk: boolean;
  magnitude: number;
}

const Visualization: React.FC<VisualizationProps> = ({
  disasterMode,
  location,
  setLocation,
  blastRadius,
  craterSize,
  tsunamiRisk,
  magnitude
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    // Simple check for ocean vs land based on a SVG path (not implemented, using rough areas)
    // A more robust solution would use a point-in-polygon check on an SVG world map path.
    const isOcean = !(x > 10 && x < 35 && y > 20 && y < 60) && // N America
                    !(x > 45 && x < 65 && y > 15 && y < 55) && // Europe/Asia
                    !(x > 45 && x < 60 && y > 55 && y < 85); // Africa
    
    const name = isOcean ? 'in the open ocean' : 'on a continental landmass';
    setLocation({ x, y, isOcean, name });
  };

  const scale = 5; // Visual scaling factor for effects
  const blastSize = Math.min(blastRadius * scale, 100);
  const craterDisplaySize = Math.min(craterSize * scale, 100);
  const earthquakeEffectSize = Math.min(Math.pow(1.9, magnitude) * 0.5, 100);

  return (
    <div className="w-full h-full flex items-center justify-center">
      <div ref={containerRef} onClick={handleClick} className="relative w-[300px] h-[300px] sm:w-[400px] sm:h-[400px] cursor-crosshair group">
        <EarthIcon className="absolute inset-0 w-full h-full text-blue-800" />
        <div className="absolute inset-0 w-full h-full bg-black/10 rounded-full" />

        {/* Effects Layer */}
        <div className="absolute inset-0">
          <div style={{ left: `${location.x}%`, top: `${location.y}%` }} className="absolute -translate-x-1/2 -translate-y-1/2">
            {disasterMode === DisasterModeEnum.Asteroid && (
              <>
                {/* Crater */}
                {!location.isOcean && craterSize > 0 && (
                  <div style={{ width: `${craterDisplaySize}px`, height: `${craterDisplaySize}px` }} className="absolute -translate-x-1/2 -translate-y-1/2 bg-yellow-900/80 rounded-full animate-crater" />
                )}
                {/* Blast Radius */}
                <div style={{ width: `${blastSize}px`, height: `${blastSize}px` }} className="absolute -translate-x-1/2 -translate-y-1/2 border-2 border-red-500 bg-red-500/20 rounded-full animate-pulse-fast" />
                {/* Tsunami Waves */}
                {tsunamiRisk && (
                    <>
                        <div style={{ width: `${blastSize * 1.5}px`, height: `${blastSize * 1.5}px` }} className="absolute -translate-x-1/2 -translate-y-1/2 border border-cyan-400 rounded-full animate-wave" />
                        <div style={{ width: `${blastSize * 1.5}px`, height: `${blastSize * 1.5}px`, animationDelay: '1s' }} className="absolute -translate-x-1/2 -translate-y-1/2 border border-cyan-400 rounded-full animate-wave" />
                    </>
                )}
              </>
            )}

            {disasterMode === DisasterModeEnum.Earthquake && (
                 <>
                    {/* Epicenter Pulse */}
                    <div style={{ width: `${earthquakeEffectSize/4}px`, height: `${earthquakeEffectSize/4}px` }} className="absolute -translate-x-1/2 -translate-y-1/2 bg-orange-500 rounded-full animate-pulse-fast"/>
                    {/* Seismic Waves */}
                    <div style={{ width: `${earthquakeEffectSize}px`, height: `${earthquakeEffectSize}px`, animationDelay: '0s' }} className="absolute -translate-x-1/2 -translate-y-1/2 border-2 border-orange-400 rounded-full animate-wave" />
                    <div style={{ width: `${earthquakeEffectSize}px`, height: `${earthquakeEffectSize}px`, animationDelay: '0.75s' }} className="absolute -translate-x-1/2 -translate-y-1/2 border-2 border-orange-400 rounded-full animate-wave" />
                    <div style={{ width: `${earthquakeEffectSize}px`, height: `${earthquakeEffectSize}px`, animationDelay: '1.5s' }} className="absolute -translate-x-1/2 -translate-y-1/2 border-2 border-orange-400 rounded-full animate-wave" />
                 </>
            )}
            
            {/* Target Marker */}
            <div className="absolute w-4 h-4 -translate-x-1/2 -translate-y-1/2">
                <div className="w-full h-full rounded-full bg-white/50 animate-ping-slow"/>
                <div className="absolute inset-0 w-full h-full rounded-full border-2 border-white"/>
            </div>
          </div>
        </div>

        <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-xs text-gray-400 bg-gray-900/50 px-2 py-1 rounded">
          Click to set impact/epicenter location
        </div>
      </div>
      <style jsx>{`
        @keyframes pulse-fast {
            0% { transform: scale(.95); opacity: 1; }
            70% { transform: scale(1.1); opacity: 0; }
            100% { transform: scale(1.1); opacity: 0; }
        }
        .animate-pulse-fast { animation: pulse-fast 1.5s cubic-bezier(0, 0, 0.2, 1) infinite; }
        
        @keyframes ping-slow {
            75%, 100% { transform: scale(2); opacity: 0; }
        }
        .animate-ping-slow { animation: ping-slow 2s cubic-bezier(0, 0, 0.2, 1) infinite; }
        
        @keyframes crater {
            from { transform: scale(0.1); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .animate-crater { animation: crater 0.5s ease-out forwards; }
        
        @keyframes wave {
            0% { transform: scale(0.1); opacity: 1; }
            100% { transform: scale(1.5); opacity: 0; }
        }
        .animate-wave { animation: wave 3s ease-out infinite; }
      `}</style>
    </div>
  );
};

export default Visualization;
