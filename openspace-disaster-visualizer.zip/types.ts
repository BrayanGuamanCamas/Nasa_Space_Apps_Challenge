
export enum DisasterMode {
  Asteroid = 'ASTEROID',
  Earthquake = 'EARTHQUAKE',
}

export interface Location {
  x: number;
  y: number;
  isOcean: boolean;
  name: string;
}

export interface AsteroidParams {
  diameter: number; // in meters
  velocity: number; // in km/s
  angle: number; // in degrees
}

export interface EarthquakeParams {
  magnitude: number; // on Richter scale
}

export interface CloseApproachAsteroid {
    name: string;
    diameter: number; // meters
    velocity: number; // km/s
}
