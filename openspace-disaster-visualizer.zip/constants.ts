
import type { CloseApproachAsteroid, Location } from './types';

export const PRESET_ASTEROIDS: CloseApproachAsteroid[] = [
    { name: '2001 FO32', diameter: 550, velocity: 34.4 },
    { name: 'Apophis', diameter: 370, velocity: 30.7 },
    { name: 'Bennu', diameter: 490, velocity: 28.0 },
    { name: 'Didymos', diameter: 780, velocity: 17.0 },
];

export const PRESET_FAULT_LINES: { name: string, location: Location }[] = [
    { name: 'San Andreas Fault', location: { x: 20, y: 40, isOcean: false, name: 'off the coast of California' } },
    { name: 'Japan Trench', location: { x: 80, y: 40, isOcean: true, name: 'in the Japan Trench' } },
    { name: 'Sunda Megathrust', location: { x: 70, y: 70, isOcean: true, name: 'near the Sunda Megathrust' } },
];

export const EARTH_DIAMETER_KM = 12742;
