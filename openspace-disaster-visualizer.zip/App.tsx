
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import type { AsteroidParams, EarthquakeParams, Location, DisasterMode } from './types';
import { DisasterMode as DisasterModeEnum } from './types';
import ControlPanel from './components/ControlPanel';
import Visualization from './components/Visualization';
import ScenarioInfo from './components/ScenarioInfo';
import Header from './components/Header';
import { generateScenarioDescription } from './services/geminiService';

const App: React.FC = () => {
  const [disasterMode, setDisasterMode] = useState<DisasterMode>(DisasterModeEnum.Asteroid);
  
  const [asteroidParams, setAsteroidParams] = useState<AsteroidParams>({
    diameter: 100,
    velocity: 20,
    angle: 45,
  });

  const [earthquakeParams, setEarthquakeParams] = useState<EarthquakeParams>({
    magnitude: 7.0,
  });

  const [location, setLocation] = useState<Location>({ 
    x: 50, 
    y: 50, 
    isOcean: true, 
    name: 'in the middle of the Pacific Ocean' 
  });

  const [scenarioInfo, setScenarioInfo] = useState({
    title: '',
    description: '',
    data: {},
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const impactEnergy = useMemo(() => {
    // Simplified energy calculation: E = 0.5 * m * v^2
    // Assuming density of 3000 kg/m^3
    const radius = asteroidParams.diameter / 2;
    const volume = (4/3) * Math.PI * Math.pow(radius, 3);
    const mass = volume * 3000;
    const velocityMetersPerSecond = asteroidParams.velocity * 1000;
    const energyJoules = 0.5 * mass * Math.pow(velocityMetersPerSecond, 2);
    return energyJoules / 4.184e15; // Convert to Megatons of TNT
  }, [asteroidParams]);

  const blastRadius = useMemo(() => {
    // Simplified scaling law
    return Math.pow(impactEnergy, 1/3) * 1.5; // in km
  }, [impactEnergy]);

  const craterSize = useMemo(() => {
    if (location.isOcean) return 0;
    return Math.pow(impactEnergy, 1/3.4) * 0.08; // in km
  }, [impactEnergy, location]);

  const tsunamiRisk = useMemo(() => {
    if (disasterMode === DisasterModeEnum.Asteroid) {
        return location.isOcean && impactEnergy > 100;
    }
    return location.isOcean && earthquakeParams.magnitude > 7.5;
  }, [disasterMode, location.isOcean, impactEnergy, earthquakeParams.magnitude]);


  const fetchScenario = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { title, description } = await generateScenarioDescription(
        disasterMode,
        disasterMode === DisasterModeEnum.Asteroid ? asteroidParams : earthquakeParams,
        location,
        { impactEnergy, blastRadius, craterSize, tsunamiRisk }
      );
      
      let data = {};
      if (disasterMode === DisasterModeEnum.Asteroid) {
          data = {
              "Impact Energy (MT)": impactEnergy.toExponential(2),
              "Blast Radius (km)": blastRadius.toFixed(2),
              "Crater Diameter (km)": craterSize.toFixed(2),
              "Tsunami Generated": tsunamiRisk ? 'High Probability' : 'Low Probability',
          };
      } else {
           data = {
              "Magnitude": earthquakeParams.magnitude.toFixed(1),
              "Tsunami Generated": tsunamiRisk ? 'High Probability' : 'Low Probability',
           }
      }
      setScenarioInfo({ title, description, data });

    } catch (err) {
      setError('Failed to generate scenario. Please check your API key and try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [disasterMode, asteroidParams, earthquakeParams, location, impactEnergy, blastRadius, craterSize, tsunamiRisk]);

  useEffect(() => {
    const handler = setTimeout(() => {
      fetchScenario();
    }, 1000); // Debounce API calls

    return () => {
      clearTimeout(handler);
    };
  }, [fetchScenario]);


  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans flex flex-col p-4 sm:p-6 lg:p-8">
      <Header />
      <main className="flex-grow grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 mt-6">
        <div className="lg:col-span-1 bg-gray-800/50 rounded-lg shadow-2xl p-6 backdrop-blur-sm border border-gray-700">
          <ControlPanel
            disasterMode={disasterMode}
            setDisasterMode={setDisasterMode}
            asteroidParams={asteroidParams}
            setAsteroidParams={setAsteroidParams}
            earthquakeParams={earthquakeParams}
            setEarthquakeParams={setEarthquakeParams}
            setLocation={setLocation}
          />
        </div>
        <div className="lg:col-span-2 grid grid-rows-2 gap-6 lg:gap-8">
            <div className="bg-gray-800/50 rounded-lg shadow-2xl p-6 backdrop-blur-sm border border-gray-700 flex items-center justify-center relative overflow-hidden">
                <Visualization 
                    disasterMode={disasterMode}
                    location={location}
                    setLocation={setLocation}
                    blastRadius={blastRadius}
                    craterSize={craterSize}
                    tsunamiRisk={tsunamiRisk}
                    magnitude={earthquakeParams.magnitude}
                />
            </div>
            <div className="bg-gray-800/50 rounded-lg shadow-2xl p-6 backdrop-blur-sm border border-gray-700">
                <ScenarioInfo 
                    info={scenarioInfo} 
                    isLoading={isLoading} 
                    error={error} 
                />
            </div>
        </div>
      </main>
    </div>
  );
};

export default App;
