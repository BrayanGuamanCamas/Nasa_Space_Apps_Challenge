
import { GoogleGenAI, Type } from '@google/genai';
import type { AsteroidParams, EarthquakeParams, Location, DisasterMode } from '../types';
import { DisasterMode as DisasterModeEnum } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

interface ScenarioCalculations {
    impactEnergy: number;
    blastRadius: number;
    craterSize: number;
    tsunamiRisk: boolean;
}

export const generateScenarioDescription = async (
  mode: DisasterMode,
  params: AsteroidParams | EarthquakeParams,
  location: Location,
  calculations: ScenarioCalculations
): Promise<{ title: string; description: string }> => {
  let prompt: string;

  if (mode === DisasterModeEnum.Asteroid) {
    const aParams = params as AsteroidParams;
    prompt = `
      Analyze the 'what-if' scenario of an asteroid impact.
      
      Scenario Details:
      - Asteroid Diameter: ${aParams.diameter} meters
      - Impact Velocity: ${aParams.velocity} km/s
      - Impact Angle: ${aParams.angle} degrees
      - Impact Location: ${location.name} (${location.isOcean ? 'Ocean' : 'Land'})
      
      Calculated Effects:
      - Impact Energy: ${calculations.impactEnergy.toExponential(2)} Megatons of TNT
      - Estimated Blast Radius: ${calculations.blastRadius.toFixed(2)} km
      - Estimated Crater Diameter: ${calculations.craterSize.toFixed(2)} km
      - Tsunami Possibility: ${calculations.tsunamiRisk ? 'High' : 'Low'}

      Based on this data, provide a title for the event and a compelling, descriptive summary (2-3 paragraphs) for an educational visualization tool. 
      Focus on the immediate and short-term consequences. Be scientific and engaging, but avoid overly technical jargon. Explain what would be observed and the scale of the destruction. If it's an ocean impact, describe the tsunami generation.
    `;
  } else {
    const eParams = params as EarthquakeParams;
    prompt = `
      Analyze the 'what-if' scenario of a major earthquake.

      Scenario Details:
      - Earthquake Magnitude: ${eParams.magnitude.toFixed(1)}
      - Epicenter Location: ${location.name} (${location.isOcean ? 'Submarine' : 'Terrestrial'})
      - Tsunami Possibility: ${calculations.tsunamiRisk ? 'High' : 'Low'}

      Based on this data, provide a title for the event and a compelling, descriptive summary (2-3 paragraphs) for an educational visualization tool.
      Focus on the potential for ground deformation (simulating NASA ARIA data) and, if applicable, the resulting tsunami. Explain the scale of the event and its likely consequences. Be scientific and engaging.
    `;
  }
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING, description: 'A catchy title for the disaster event.' },
                description: { type: Type.STRING, description: 'A 2-3 paragraph summary of the event\'s consequences.' }
            },
            required: ['title', 'description']
        }
    }
  });

  try {
    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);
    return {
      title: result.title || 'Scenario Analysis',
      description: result.description || 'No description generated.'
    };
  } catch(e) {
    console.error("Failed to parse Gemini response:", e);
    return {
      title: 'Error Parsing Response',
      description: 'The AI model returned a response that could not be understood. Please try adjusting the parameters.'
    }
  }
};
